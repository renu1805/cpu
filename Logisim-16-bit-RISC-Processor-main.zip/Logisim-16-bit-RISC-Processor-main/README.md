# Logisim-16-bit-RISC-Processor
Logisim implementation of a 16-bit single cycle and pipelined RISC processor designed from an instruction set.
